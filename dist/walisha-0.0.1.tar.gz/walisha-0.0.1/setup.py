# for installing local package
from setuptools import setup, find_packages

setup(
    name="walisha",
    version="0.0.1",
    author="Walisha",
    author_email="walishatahir00@gmail.com",
    packages=find_packages(),  # finds all packages with __init__.py
    install_requires=[
        "openai",
        "langchain",
        "streamlit",
        "python-dotenv",
        "PyPDF2"
    ],
    python_requires=">=3.13.5",
)
